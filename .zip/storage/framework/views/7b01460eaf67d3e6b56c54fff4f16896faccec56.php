<a href="/">
    <img src="assets/images/logo.png" />
</a><?php /**PATH C:\laragon\www\thirdplatoon\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>