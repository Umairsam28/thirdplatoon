<a href="/">
    <img src="assets/images/logo.png" />
</a><?php /**PATH /home/dynamiccreatived/thirdplatoon.creativedesigndok.com/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>