
<?php $__env->startSection('content'); ?>
<section class="banner-area">
    <div class="banner-content-area">
        <h2>Shop</h2>
    </div>
</section>
<section class="shop-sec">
    <div class="container">
        <div class="row">
            <div class="col-md-3 category-wrap">
                <h2>Categories</h2>
                <ul class="category-select">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($category->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <h2>MOST VIEWED</h2>
                <ul class="small-product-card">
                    <?php $__currentLoopData = $mostViewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php if(count($mv->images)>0): ?>
                            <img src="<?php echo e(asset('storage/products/'.$mv->id.'/'.$mv->images[0]->image_path)); ?>" />
                        <?php else: ?>
                            <img src="assets/images/placeholder.png" />
                        <?php endif; ?>
                        <h4><?php echo e($mv->name); ?></h4>
                        <span>$<?php echo e($mv->price); ?></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-md-9">
                <div class="row products_list">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 product-card">
                            <?php if(count($product->images)>0): ?>
                            <img src="<?php echo e(asset('storage/products/'.$product->id.'/'.$product->images[0]->image_path)); ?>" />
                            <?php else: ?>
                                <img src="assets/images/placeholder.png" />
                            <?php endif; ?>
                            <h4><?php echo e($product->name); ?></h4>
                            <h5>$<?php echo e($product->price); ?></h5>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\m.yaseen\Desktop\projects\thirdplatoon\resources\views/frontend/ecommerce/product/index.blade.php ENDPATH**/ ?>