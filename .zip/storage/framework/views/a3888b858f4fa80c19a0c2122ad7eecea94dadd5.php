<a href="/">
    <img src="assets/images/logo.png" />
</a><?php /**PATH C:\Users\m.yaseen\Desktop\projects\thirdplatoon\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>