

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="banner-area">
    <div class="banner-content-area">
        <h2>Jobs Listing</h2>
    </div>
</section>

<div class="container cta-100">

    <section class="jobs-wrapper">
        <div class="row">
            <div class="col-md-4">
                <aside class="jobs-sidebar">
                    <div class="meta-box">
                        <div class="meta-head">
                            <h3><a href="#search-keywords" data-toggle="collapse" aria-expanded="true">Search Keywords</a></h3>
                        </div>
                        <div class="meta-body collapse in" id="search-keywords">
                            <div class="meta-inner-wrap">
                                <form>
                                    <div class="input-group">
                                        <input type="text" name="search" id="search" class="input-control" placeholder="e.g. Web Design" value="<?php echo e(request()->get('search')); ?>">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="meta-box">
                        <div class="meta-head">
                            <h3><a href="#category" data-toggle="collapse" aria-expanded="true">Category</a></h3>
                        </div>
                        <div class="meta-body collapse in" id="category">
                            <div class="meta-inner-wrap">
                                <?php if($categories->count()): ?>
                                    <ul class="meta-list">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e($category->link); ?>"><?php echo e($category->title); ?> (<?php echo e($category->jobs()->ApplicationAvail()->count()); ?>)</a></li>        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </aside>
            </div>
            <div class="col-md-8">
                <div class="jobs-head">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="jobs-results">
                                Showing <?php echo e($jobs->firstItem() ?? 0); ?> – <?php echo e($jobs->lastItem() ?? 0); ?> of <?php echo e($jobs->total() ?? 0); ?> results
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="jobs-filters">
                                <form>
                                    <div class="input-group input-group-inline">
                                        <label>Sort by:</label>
                                        <select name="orderby" id="orderby" class="input-control" onchange="this.form.submit()">
                                            <option value="">Default</option>
                                            <option value="newest" <?php echo e(request()->get('orderby') == 'newest' ? 'selected' : ''); ?>>Newest</option>
                                            <option value="oldest" <?php echo e(request()->get('orderby') == 'oldest' ? 'selected' : ''); ?>>Oldest</option>
                                        </select>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="jobs-listing">
                    <?php if($jobs->count()): ?>
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="job-block">
                                <div class="job-block-head">
                                    <div class="job-block-employer-header">
                                        <div class="job-block-employer-logo">
                                            <img src="<?php echo e($job->company_logo_path); ?>" alt="<?php echo e($job->company_name); ?>"
                                                title="<?php echo e($job->company_name); ?>">
                                        </div>
                                        <div class="job-block-title-wrapper">
                                            <span class="label label-primary"><?php echo e($job->category->title); ?></span>
                                            <h3 class="job-block-employer-title"><a href="<?php echo e($job->link); ?>"><?php echo e($job->company_name); ?></a></h3>
                                            <h4 class="job-block-title"><?php echo e($job->designation); ?></h4>
                                        </div>
                                    </div>
                                    <?php if($job->featured): ?>
                                        <a href="javascript:;" class="job-block-featured" data-toggle="tooltip" data-placement="left" title="Featured"><i class="fa fa-star"></i></a>
                                    <?php endif; ?>
                                    <?php if($job->urgent): ?>
                                        <div class="job-block-urgent-label">Urgent</div>
                                    <?php endif; ?>                                        
                                </div>
                                <div class="job-block-body">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="job-block-information">
                                                <p><strong>Deadline date:</strong> <span><?php echo e($job->deadline_date); ?></span></p>
                                                <p><strong>Job Type:</strong> <span class="text-green"><?php echo e($job->type); ?></span></p>
                                                <p><strong>Location:</strong> <span><?php echo e($job->location); ?></span></p>
                                                <p><strong>Salary:</strong> <span><?php echo e($job->pay_start_format); ?> – <?php echo e($job->pay_end_format); ?> <?php echo e($job->pay_per); ?></span></p>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="job-block-btns">
                                                <div class="job-block-deadline-time">Application ends:&nbsp;<strong><?php echo e($job->deadline_date); ?></strong></div>
                                                <?php if($job->application_ends): ?>
                                                    <?php if($job->job_user): ?>
                                                        <div class="text-center">
                                                            <strong class="text-info">Already Applied</strong>
                                                        </div>
                                                        <br>
                                                    <?php else: ?>
                                                        <a href="<?php echo e($job->apply_url); ?>" class="btn btn-apply">Apply Now</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a href="<?php echo e($job->link); ?>" class="btn btn-view">View Job</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($jobs->links('vendor.pagination.pagination')); ?>

                    <?php else: ?>
                        <div class="alert alert-info">No Jobs Found!</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\thirdplatoon\resources\views/frontend/jobs/index.blade.php ENDPATH**/ ?>