<footer>
    <div class="container">
        <div class="col-md-3">
            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-responsive">
        </div>
        <div class="col-md-3">
            <h4>Need Help</h4>
            <ul>
                <li>Call us on (616) 375 2513</li>
                <li>Email: info@th3rdplatoon.com</li>
            </ul>
        </div>
        <div class="col-md-3">
            <h4>Quick Links</h4>
            <ul class="quick-ul">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
                <li><a href="<?php echo e(route('contact_us')); ?>">Contact Us</a></li>
                <li><a href="<?php echo e(route('categories')); ?>">Categories</a></li>
                <li><a href="<?php echo e(route('ads.create')); ?>">Post Ads</a></li>
                <li><a href="/blog">Blog </a></li>
            </ul>
        </div>
        <div class="col-md-3">
            <h4>Get Social With Us</h4>
            <ul class="footer-social">
                <li><i class="fa fa-facebook" aria-hidden="true"></i></li>
                <li><i class="fa fa-twitter" aria-hidden="true"></i></li>
                <li><i class="fa fa-linkedin-square" aria-hidden="true"></i></li>
                <li><i class="fa fa-pinterest-p" aria-hidden="true"></i></li>
                <li><i class="fa fa-google-plus-official" aria-hidden="true"></i></li>
            </ul>
        </div>
        <section class="copyright">
            <div class="col-md-6">
                <p>© Copyright 2020 Th3rdPlatoon. All Rights Reserved</p>
            </div>
            <div class="col-md-6">
                <ul class="foot-ul">
                    <li><a href="<?php echo e(route('terms')); ?>">Terms & Conditions</a></li>
                    <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                </ul>
            </div>
        </section>
    </div>
</footer><?php /**PATH C:\laragon\www\thirdplatoon\resources\views/layouts/frontend/partials/footer.blade.php ENDPATH**/ ?>