

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="banner-area">
    <div class="banner-content-area">
        <h2>Blog</h2>
    </div>
</section>

<div class="container cta-100">

    <section class="blog-wrap">
        <div class="single-post-wrap">
            <article class="sarticle-box">
                <?php if($post->image): ?>
                    <div class="sarticle-img">
                        <img src="<?php echo e($post->image_path); ?>" alt="<?php echo e($post->title); ?>" title="<?php echo e($post->title); ?>">
                    </div>
                <?php endif; ?>
                <div class="sarticle-content">
                    <div class="sarticle-meta">
                        <ul class="list-unstyled">
                            <li><i class="fa fa-clock-o"></i><span><?php echo e($post->created_at->format('d M Y')); ?></span></li>
                            <li><i class="fa fa-tag"></i><span><?php echo e($post->category->title); ?></span></li>
                        </ul>
                    </div>
                    <h3><?php echo e($post->title); ?></h3>
                    <p><?php echo e($post->description); ?></p>
                </div>
            </article>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dynamiccreatived/thirdplatoon.creativedesigndok.com/resources/views/frontend/blog/show.blade.php ENDPATH**/ ?>