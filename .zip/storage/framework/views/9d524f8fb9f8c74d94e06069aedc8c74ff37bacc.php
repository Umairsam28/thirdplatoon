
<?php $__env->startSection('content'); ?>
<section class="banner-area">
    <div class="banner-content-area">
        <h2>Categories</h2>
    </div>
</section>
<?php if($categories->count()): ?>
    <section class="browse-categories main-section">
        <div class="container">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-2 browse-box">
                    <a href="<?php echo e($category->path()); ?>">
                        <img src="<?php echo e($category->image()); ?>">
                        <h4><?php echo e($category->title); ?></h4>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dynamiccreatived/thirdplatoon.creativedesigndok.com/resources/views/frontend/categories.blade.php ENDPATH**/ ?>