

<?php $__env->startSection('content'); ?>
<section class="banner-area">
    <div class="banner-content-area">
        <h2>Post Ads</h2>
    </div>
</section>
<section class="main-section">
	<div class="container">
		<?php if(session()->has('msg')): ?>
			<?php if(session()->get('msg')['type'] == 'success'): ?>
				<div class="alert alert-success"><?php echo e(session()->get('msg')['text']); ?></div>
			<?php endif; ?>
			<?php if(session()->get('msg')['type'] == 'error'): ?>
				<div class="alert alert-danger"><?php echo e(session()->get('msg')['text']); ?></div>
			<?php endif; ?>
		<?php endif; ?>
		<div class="main-panel">
			<div class="mp-body">
				<form action="<?php echo e(route('ads.store')); ?>" method="POST" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label for="title">Title <span class="text-danger">*</span></label>
								<input type="text" name="title" id="title" placeholder="Enter Title" class="form-control" value="<?php echo e(old('title')); ?>">
								<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="text-danger"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="category">Category <span class="text-danger">*</span></label>
								<select name="category" id="category" class="form-control">
									<option value="">Select Category</option>
									<?php if($categories->count()): ?>
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($category->id); ?>" <?php echo e(old('category') == $category->id ? 'selected' : ''); ?>><?php echo e(ucwords($category->title)); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</select>
								<?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="text-danger"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="price">Price <span class="text-danger">*</span></label>
								<div class="input-group">
							      	<div class="input-group-addon"><?php echo e(currency_symbol()); ?></div>
							      	<input type="text" name="price" id="price" placeholder="0.00" class="form-control" value="<?php echo e(old('price')); ?>">
							    </div>
						      	<?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="text-danger"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="image">Image <span class="text-danger">*</span></label>
								<input type="file" name="image" id="image" class="form-control">
								<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<div class="text-danger"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label for="description">Description</label>
								<textarea name="description" id="description" class="form-control" rows="5"><?php echo e(old('description')); ?></textarea>
							</div>
						</div>
						<div class="col-md-12">
							<button type="submit" class="btn btn-base">Submit</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dynamiccreatived/thirdplatoon.creativedesigndok.com/resources/views/frontend/ads/create.blade.php ENDPATH**/ ?>