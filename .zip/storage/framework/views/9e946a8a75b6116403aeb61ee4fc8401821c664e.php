

<?php $__env->startSection('content'); ?>
<section class="banner-area">
    <div class="banner-content-area">
        <h2>Ads</h2>
    </div>
</section>
<section class="main-section">
    <div class="container">
        <?php if(session()->has('msg')): ?>
        <?php if(session()->get('msg')['type'] == 'success'): ?>
        <div class="alert alert-success"><?php echo e(session()->get('msg')['text']); ?></div>
        <?php endif; ?>
        <?php if(session()->get('msg')['type'] == 'error'): ?>
        <div class="alert alert-danger"><?php echo e(session()->get('msg')['text']); ?></div>
        <?php endif; ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-4">
                <form action="<?php echo e(route('ads.index')); ?>" method="GET">
                    <div class="filter-box main-panel">
                        <div class="main-head">
                            <h3>Search Filters</h3>
                        </div>
                        <hr>
                        <div class="form-group">
                            <label for="search">Search</label>
                            <input type="text" name="search" id="search" placeholder="Search...." class="form-control"
                                value="<?php echo e(request()->get('search')); ?>">
                        </div>
                        <hr>
                        <div class="form-group">
                            <label for="category">Category</label>
                            <select name="category" id="category" class="form-control">
                                <option value="">Select Category</option>
                                <?php if($categories->count()): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e(request()->get('category') == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e(ucwords($category->title)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <hr>
                        <div class="form-group">
                            <label for="min_price">Price</label>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="number" name="min_price" id="min_price" placeholder="Min Price" class="form-control" value="<?php echo e(request()->get('min_price')); ?>">
                                </div>
                                <div class="col-md-6">
                                    <input type="number" name="max_price" id="max_price" placeholder="Max Price" class="form-control" value="<?php echo e(request()->get('max_price')); ?>">
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <button type="submit" class="btn btn-base">Search</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-8">
                <?php if($ads->count()): ?>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="ad-box">
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e($ad->image()); ?>" alt="<?php echo e($ad->title); ?>" class="img-responsive img-thumbnail">
                        </div>
                        <div class="col-md-8">
                            <span class="label label-success"><?php echo e(ucwords($ad->category->title)); ?></span>
                            <h4><?php echo e(ucwords($ad->title)); ?></h4>
                            <strong class="text-danger"><?php echo e(currency_symbol()); ?><?php echo e($ad->price()); ?></strong>
                            <br><br>
                            <p><?php echo e(substr($ad->description, 0, 50)); ?>..</p>
                            <hr>
                            <div class="text-right">
                                <a href="<?php echo e($ad->link); ?>" class="btn btn-base btn-sm">More Details</a>
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <?php echo e($ads->links()); ?>

                </div>
                <?php else: ?>
                <div class="well">No Ads Found!</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dynamiccreatived/thirdplatoon.creativedesigndok.com/resources/views/frontend/ads/index.blade.php ENDPATH**/ ?>