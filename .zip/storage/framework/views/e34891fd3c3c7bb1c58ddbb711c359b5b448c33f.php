

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="banner-area">
    <div class="banner-content-area">
        <h2>Blog</h2>
    </div>
</section>

<div class="container cta-100">

    <section class="blog-wrap">
        <?php if($posts->count()): ?>
            <div class="posts-wrap">
                <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4">
                            <article class="article-box">
                                <div class="article-img">
                                    <a href="<?php echo e($post->link); ?>"><img src="<?php echo e($post->image_path); ?>" alt="<?php echo e($post->title); ?>" title="<?php echo e($post->title); ?>"></a>
                                </div>
                                <div class="article-content">
                                    <div class="article-category"><?php echo e($post->category->title); ?></div>
                                    <h3><a href="<?php echo e($post->link); ?>"><?php echo e($post->title); ?></a></h3>
                                    <p><?php echo e($post->excerpt); ?></p>
                                    <div class="article-date"><?php echo e($post->created_at->format('d M Y')); ?></div>
                                </div>
                            </article>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="paginate-wrap">
                <?php echo e($posts->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        <?php else: ?>
            <div class="alert alert-danger">
                No Record Found!
            </div>
        <?php endif; ?>
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dynamiccreatived/thirdplatoon.creativedesigndok.com/resources/views/frontend/blog/index.blade.php ENDPATH**/ ?>