<p>
    <strong>Fullname: </strong>
    <span>{{ $data['fullname'] }}</span>
</p>
<p>
    <strong>Email: </strong>
    <span>{{ $data['email'] }}</span>
</p>
<p>
    <strong>Subject: </strong>
    <span>{{ $data['subject'] }}</span>
</p>
<p><strong>Message: </strong></p>
<p>{{ $data['message'] }}</p>
