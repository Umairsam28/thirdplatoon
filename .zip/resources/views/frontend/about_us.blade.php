@extends('layouts.frontend.app')
@section('content')
<section class="banner-area">
    <div class="banner-content-area">
        <h2>About Us</h2>
    </div>
</section>
<section class="about-sec">
    <div class="col-md-6 about-left">
        <img src="assets/images/sec2-1.png">
    </div>
    <div class="col-md-6 about-right">
        <p>Nisi minim anim ut proident aliqua in id eu fugiat consectetur in amet anim laboris laboris ullamco et in incididunt sit et ut enim velit id veniam veniam anim amet ullamco minim sint culpa et culpa fugiat ex aute laborum laboris nulla esse aliqua dolor dolor minim laborum do minim pariatur proident aliquip tempor reprehenderit in cillum cillum et anim duis laborum cupidatat nostrud ex excepteur irure duis non pariatur pariatur quis qui in in voluptate est in nostrud nisi est ullamco do consectetur consectetur ex et in elit ut sit do esse veniam minim ut consectetur velit elit nulla commodo dolore ut velit cupidatat in sint minim voluptate nisi in ullamco in exercitation cupidatat non sit tempor qui ut non nisi officia cillum eu est nostrud deserunt magna cupidatat dolor culpa consequat eiusmod sint do eiusmod labore fugiat cupidatat incididunt quis exercitation non consectetur.</p>
    </div>
</section>
@endsection
